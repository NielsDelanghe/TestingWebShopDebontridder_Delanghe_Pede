package domain.model;

public enum Role {

    ADMIN,
    CUSTOMER;
}
